# to generate random 400 workers
# Using Faker, which is a python library to generate realistic-looking fake data for the names for the workers

from faker import Faker
import random

# initialize Faker

fake = Faker()
workers = []

# function to input worker information in the workers array

for i in range(1, 401):
    try:
        name = fake.name()
        gender = random.choice(["male", "female"])
        salary = round(random.uniform(5000, 30000), 2)

        worker = {
            "id": i,
            "name": name,
            "gender": gender,
            "salary": salary
        }

        workers.append(worker)

# handing potential errors using except to specify error notification for easy understanding

    except Exception as e:
        print(f"Error creating worker #{i}: {e}")

# to determine employee level based on salary and gender and generate payment slips

for worker in workers:
    try:
        level = "Unassigned"

        if 10000 < worker["salary"] < 20000:
            level = "A1"
        if 7500 < worker["salary"] < 30000 and worker["gender"] == "female":
            level = "A5-F"

        worker["level"] = level

        print("PAYMENT SLIP")
        print(f"ID: {worker['id']}")
        print(f"Name: {worker['name']}")
        print(f"Gender: {worker['gender'].title()}")
        print(f"Salary: ${worker['salary']}")
        print(f"Level: {worker['level']}")
        print("\n")

    except KeyError as e:
        print(
            f"Missing information for worker ID {worker.get('id', '?')}: {e}")
    except Exception as e:
        print(f"Unexpected error with worker ID {worker.get('id', '?')}: {e}")
