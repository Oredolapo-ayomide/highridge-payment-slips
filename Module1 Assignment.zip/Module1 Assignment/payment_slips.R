#Initializing the random number generator
set.seed(123)

first_names <- c("James", "Mary", "John", "Patricia", "Michael", "Jennifer", "David", "Linda", 
                 "Robert", "Elizabeth", "Daniel", "Barbara", "Joseph", "Susan", "Paul", "Karen")

last_names <- c("Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Garcia",
                "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas")

# Generate 400 full names
names <- paste(
  sample(first_names, 400, replace = TRUE),
  sample(last_names, 400, replace = TRUE)
)

# Numeric IDs
ids <- sprintf("%04d", 1:400)

# Gender and salary
genders <- c("Male", "Female")
workers <- data.frame(
  id = ids,
  name = names,
  gender = sample(genders, 400, replace = TRUE),
  salary = sample(5000:35000, 400, replace = TRUE),
  stringsAsFactors = FALSE
)

# Employee level 
get_emp_level <- function(salary, gender) {
  level <- "Unassigned"
  if (salary > 10000 & salary < 20000) {
    level <- "A1"
  }
  if (salary > 7500 & salary < 30000 & gender == "Female") {
    level <- "A5-F"
  }
  return(level)
}

# Generate payment slips
for (i in 1:nrow(workers)) {
  tryCatch({
    level <- get_emp_level(workers$salary[i], workers$gender[i])
    cat("Payment Slip:\n")
    cat("ID:", workers$id[i], "\n")
    cat("Name:", workers$name[i], "\n")
    cat("Gender:", workers$gender[i], "\n")
    cat("Salary: $", workers$salary[i], "\n")
    cat("Employee Level:", level, "\n")
    cat(rep("-", 30), "\n")
  }, error = function(e) {
    cat("Error for worker", workers$id[i], ":", e$message, "\n")
  })
}
